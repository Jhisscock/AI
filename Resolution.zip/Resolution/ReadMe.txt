To run and compile first direct to the file folder and type "javac Resolution.java"
Next to run the program type "java Resolution"
Input the clauses one at a time hitting enter in between each
Then when you're done type "stop"